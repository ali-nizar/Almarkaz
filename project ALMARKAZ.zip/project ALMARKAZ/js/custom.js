jQuery(document).ready(function ($) {
    "use strict";
    $('#customers-testimonials').owlCarousel({
        navigation: true,
        loop: true,
        center: true,
        items: 3,
        margin: 30,
        autoplay: true,
        // dots:true,
        // nav:true,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            1170: {
                items: 3
            }
        }
    });
});
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const dots = document.querySelectorAll(".dot-container button");
const images = document.querySelectorAll(".image-container img");
let i = 0; // current slide
let j = 4;

function indicator(num) {
    dots.forEach(function (dot) {
        dot.style.backgroundColor = "transparent";
    });
    document.querySelector(".dot-container button:nth-child(" + num + ")").style.backgroundColor = "#076bb8";
}

function dot(index) {
    images.forEach(function (image) {
        image.classList.remove("active");
    });
    document.getElementById("content" + index).classList.add("active");
    i = index - 1;
    indicator(index);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


let currentIndex = 0;
const cards = document.querySelectorAll('.card');
const indicators = document.querySelectorAll('.indicator');

function goToCard(index) {
    cards[currentIndex].classList.remove('active');
    indicators[currentIndex].classList.remove('active');
    currentIndex = index;
    cards[currentIndex].classList.add('active');
    indicators[currentIndex].classList.add('active');
}

indicators.forEach((indicator, index) => {
    indicator.addEventListener('click', () => {
        goToCard(index);
    });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var button = document.getElementById("refresh-button");
button.addEventListener("click", function () {
    location.reload();
});


var button = document.getElementById("zoom-in-button");
button.addEventListener("click", function () {
    document.body.style.zoom = "110%";
});


var button = document.getElementById("zoom-out-button");
button.addEventListener("click", function () {
    document.body.style.zoom = "95%";
});


var button = document.getElementById("dark-mode-button");
button.addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
});



var button = document.getElementById("light-mode-button");
button.addEventListener("click", function () {
    document.body.classList.toggle("light-mode");
});


var button = document.getElementById("color-remover-button");
button.addEventListener("click", function () {
    document.body.classList.toggle("color-remover");
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.onscroll = function () {
    if (document.body.scrollTop > 800 || document.documentElement.scrollTop > 800) {
        document.getElementById("top-arrow").classList.add("show");
    } else {
        document.getElementById("top-arrow").classList.remove("show");
    }
};

document.getElementById("top-arrow").onclick = function () {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
};

document.getElementById("top-arrow").onclick = function () {
    window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth'
    });
};
///////////////////////////////////////////////////////////

$(document).ready(function() {
    $('.slider').slick({
      dots: true,
      infinite: true,
      speed: 300,
      slidesToShow: 1,
      adaptiveHeight: true
    });
  });
  